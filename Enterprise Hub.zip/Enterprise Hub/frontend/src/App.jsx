import { useEffect, useMemo, useState } from "react";
import Panel1GitHubCommit from "./components/Panel1_GitHubCommit";
import Panel2ConfluentStreams from "./components/Panel2_ConfluentStreams";
import Panel3FlinkDetection from "./components/Panel3_FlinkDetection";
import Panel4ClaudeRootCause from "./components/Panel4_ClaudeRootCause";
import Panel5SlackAlert from "./components/Panel5_SlackAlert";
import Panel6AutoRemediation from "./components/Panel6_AutoRemediation";
import Panel7SystemRestored from "./components/Panel7_SystemRestored";
import Timeline from "./components/Timeline";
import "./index.css";

const WS_URL = "ws://localhost:8000/ws";

const initialState = {
  step: 0,
  timeline: { "1": null, "2": null, "3": null, "4": null, "5": null, "6": null, "7": null },
  commit: null,
  prediction: null,
  streams: {
    "github-events": { count: 0, msg_per_sec: 0 },
    "app-logs": { count: 0, msg_per_sec: 0 },
    metrics: { count: 0, msg_per_sec: 0 },
    alerts: { count: 0, msg_per_sec: 0 },
  },
  flink: { job_name: "incident-detection", events_in: 0, events_out: 0, status: "RUNNING" },
  incident: null,
  analysis: null,
  slack_ts: null,
  approved: false,
  remediation_logs: [],
  system_health: { error_rate: 0.12, latency_ms: 120, success_rate: 99.98, status: "HEALTHY" },
};

function App() {
  const [connected, setConnected] = useState(false);
  const [state, setState] = useState(initialState);

  const nowClock = () => new Date().toLocaleTimeString();

  useEffect(() => {
    const ws = new WebSocket(WS_URL);

    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);
    ws.onerror = () => setConnected(false);

    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      const { type, data } = message;

      setState((prev) => {
        switch (type) {
          case "state":
            return { ...prev, ...data };
          case "commit_received":
            return {
              ...prev,
              commit: data,
              step: Math.max(prev.step, 1),
              timeline: {
                ...prev.timeline,
                "1": prev.timeline["1"] || nowClock(),
              },
            };
          case "prediction_ready":
            return { ...prev, prediction: data, step: Math.max(prev.step, 2) };
          case "stream_update":
            return {
              ...prev,
              streams: data,
              timeline: {
                ...prev.timeline,
                "2":
                  prev.timeline["2"] || ((data["github-events"]?.count || 0) > 0 ? nowClock() : null),
              },
            };
          case "incident_detected":
            return {
              ...prev,
              incident: data,
              step: Math.max(prev.step, 3),
              timeline: {
                ...prev.timeline,
                "3": prev.timeline["3"] || nowClock(),
              },
            };
          case "flink_update":
            return { ...prev, flink: data };
          case "analysis_ready":
            return {
              ...prev,
              analysis: data,
              step: Math.max(prev.step, 4),
              timeline: {
                ...prev.timeline,
                "4": prev.timeline["4"] || nowClock(),
              },
            };
          case "slack_sent":
            return {
              ...prev,
              slack_ts: data.ts,
              step: Math.max(prev.step, 5),
              timeline: {
                ...prev.timeline,
                "5": prev.timeline["5"] || nowClock(),
              },
            };
          case "fix_approved":
            return {
              ...prev,
              approved: true,
              step: Math.max(prev.step, 6),
              timeline: {
                ...prev.timeline,
                "6": prev.timeline["6"] || nowClock(),
              },
            };
          case "remediation_log":
            return {
              ...prev,
              remediation_logs: [...prev.remediation_logs, data],
              step: Math.max(prev.step, 6),
            };
          case "system_restored":
            return {
              ...prev,
              system_health: data,
              step: Math.max(prev.step, 7),
              timeline: {
                ...prev.timeline,
                "7": prev.timeline["7"] || nowClock(),
              },
            };
          default:
            return prev;
        }
      });
    };

    return () => ws.close();
  }, []);

  const stepTimestamps = useMemo(() => state.timeline || initialState.timeline, [state.timeline]);

  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>SENTINEL</h1>
        <p>We don't send alerts. We take action.</p>
        <span className={connected ? "badge badge-ok" : "badge badge-danger"}>
          {connected ? "WS CONNECTED" : "WS DISCONNECTED"}
        </span>
      </header>

      <main className="grid-wrap">
        <section className="top-row">
          <Panel1GitHubCommit commit={state.commit} prediction={state.prediction} active={state.step >= 1} />
          <Panel2ConfluentStreams streams={state.streams} active={state.step >= 2} />
          <Panel3FlinkDetection flink={state.flink} incident={state.incident} active={state.step >= 3} />
          <Panel4ClaudeRootCause analysis={state.analysis} active={state.step >= 4} />
        </section>

        <section className="bottom-row">
          <Panel5SlackAlert analysis={state.analysis} ts={state.slack_ts} active={state.step >= 5} />
          <Panel6AutoRemediation logs={state.remediation_logs} active={state.step >= 6} />
          <Panel7SystemRestored health={state.system_health} active={state.step >= 7} />
        </section>
      </main>

      <Timeline currentStep={state.step} timestamps={stepTimestamps} />
    </div>
  );
}

export default App;
