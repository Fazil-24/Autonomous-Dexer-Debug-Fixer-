function TopicRow({ name, value }) {
  return (
    <div className="row">
      <span>{name}</span>
      <span>
        {value.count} msgs | {value.msg_per_sec}/s
      </span>
    </div>
  );
}

function Panel2ConfluentStreams({ streams, active }) {
  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>CONFLUENT CLOUD - REAL TIME STREAMS</h3>
      <TopicRow name="github-events" value={streams["github-events"]} />
      <TopicRow name="app-logs" value={streams["app-logs"]} />
      <TopicRow name="metrics" value={streams.metrics} />
      <TopicRow name="alerts" value={streams.alerts} />
      <span className="badge badge-ok">Events streaming in real time (24x7)</span>
    </article>
  );
}

export default Panel2ConfluentStreams;
