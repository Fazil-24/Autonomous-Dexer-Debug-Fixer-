function Panel4ClaudeRootCause({ analysis, active }) {
  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>AI ENGINE (CLAUDE) - ROOT CAUSE</h3>
      <div className="kv">Model: Claude Sonnet 4.6</div>
      {analysis ? (
        <>
          <div className="kv">Root Cause: {analysis.root_cause}</div>
          <div className="kv">Suggested Fix: {analysis.fix}</div>
          <div className="kv">Estimated Impact: {analysis.estimated_impact}</div>
          <span className="badge badge-ok">Confidence: {analysis.confidence}%</span>
        </>
      ) : (
        <div className="kv">Awaiting incident analysis...</div>
      )}
    </article>
  );
}

export default Panel4ClaudeRootCause;
