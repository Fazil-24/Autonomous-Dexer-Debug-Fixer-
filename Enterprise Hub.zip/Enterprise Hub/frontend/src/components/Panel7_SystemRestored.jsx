function Panel7SystemRestored({ health, active }) {
  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>SYSTEM RESTORED - INCIDENT RESOLVED</h3>
      <div className="metrics-grid">
        <div className="metric-card">
          <div>Error Rate</div>
          <strong>{health.error_rate}%</strong>
        </div>
        <div className="metric-card">
          <div>Latency</div>
          <strong>{health.latency_ms}ms</strong>
        </div>
        <div className="metric-card">
          <div>Success Rate</div>
          <strong>{health.success_rate}%</strong>
        </div>
        <div className="metric-card">
          <div>Service Status</div>
          <strong>{health.status}</strong>
        </div>
      </div>
    </article>
  );
}

export default Panel7SystemRestored;
