function Panel1GitHubCommit({ commit, prediction, active }) {
  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>LIVE GITHUB COMMIT {commit?.received_at ? `- ${commit.received_at}` : ""}</h3>
      {commit ? (
        <>
          <div className="kv">Commit ID: {commit.commit_id}</div>
          <div className="kv">Author: {commit.author}</div>
          <div className="kv">Changed File: {(commit.changed_files || [])[0] || "-"}</div>
          <div className="kv">Repo: {commit.repo}</div>
          <span className="badge badge-ok">Real commit pushed</span>
          {prediction && (
            <div className="critical-box" style={{ marginTop: 10 }}>
              Prediction: {prediction.risk_level} ({prediction.crash_probability}%)
            </div>
          )}
        </>
      ) : (
        <div className="kv">Waiting for GitHub webhook...</div>
      )}
    </article>
  );
}

export default Panel1GitHubCommit;
