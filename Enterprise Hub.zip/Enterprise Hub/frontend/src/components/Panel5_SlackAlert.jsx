async function approve() {
  await fetch("http://localhost:8000/approve", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
  });
}

function Panel5SlackAlert({ analysis, ts, active }) {
  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>SLACK ALERT - MAN IN THE LOOP</h3>
      {analysis ? (
        <>
          <div className="kv">Root Cause: {analysis.root_cause}</div>
          <div className="kv">File: {analysis.problematic_file} (Line {analysis.problematic_line})</div>
          <div className="kv">Issue: {analysis.issue_summary}</div>
          <div className="kv">Impact: {analysis.estimated_impact}</div>
          <div className="kv">Fix: {analysis.fix}</div>
          <div className="kv">Slack TS: {ts || "pending"}</div>
          <div className="slack-actions">
            <button className="btn btn-approve" onClick={approve}>
              APPROVE
            </button>
            <button className="btn btn-reject">REJECT</button>
          </div>
        </>
      ) : (
        <div className="kv">Slack alert not sent yet...</div>
      )}
    </article>
  );
}

export default Panel5SlackAlert;
