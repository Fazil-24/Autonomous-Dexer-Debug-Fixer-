function Panel3FlinkDetection({ flink, incident, active }) {
  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>FLINK - REAL TIME DETECTION</h3>
      <div className="kv">Job: {flink.job_name}</div>
      <div className="row">
        <span>Events In</span>
        <strong>{flink.events_in}</strong>
      </div>
      <div className="row">
        <span>Events Out</span>
        <strong>{flink.events_out}</strong>
      </div>
      <div className="row">
        <span>Status</span>
        <span className="badge badge-ok">{flink.status}</span>
      </div>
      {incident && (
        <div className="critical-box">INCIDENT DETECTED - High error rate in auth-service</div>
      )}
    </article>
  );
}

export default Panel3FlinkDetection;
