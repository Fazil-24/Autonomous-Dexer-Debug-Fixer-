import { useEffect, useRef } from "react";

function Panel6AutoRemediation({ logs, active }) {
  const logBoxRef = useRef(null);

  useEffect(() => {
    if (logBoxRef.current) {
      logBoxRef.current.scrollTop = logBoxRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <article className={`panel ${active ? "active" : ""}`}>
      <h3>APPROVAL RECEIVED - AUTO REMEDIATION STARTED</h3>
      <div className="log-box" ref={logBoxRef}>
        {logs.length === 0 ? (
          <div className="log-line">Waiting for approval and remediation logs...</div>
        ) : (
          logs.map((log, idx) => (
            <div key={`${log.time}-${idx}`} className="log-line">
              {log.time} [{log.level}] {log.message}
            </div>
          ))
        )}
      </div>
    </article>
  );
}

export default Panel6AutoRemediation;
