const steps = [
  "Developer pushes code",
  "Event ingested by Confluent",
  "Flink detects incident",
  "AI finds root cause",
  "Slack alert sent",
  "Approval received",
  "System restored",
];

function Timeline({ currentStep, timestamps }) {
  return (
    <section className="timeline">
      <h3>TIMELINE</h3>
      <div className="timeline-list">
        {steps.map((title, idx) => {
          const step = idx + 1;
          const active = currentStep >= step;
          return (
            <div key={title} className={`timeline-step ${active ? "active" : ""}`}>
              <div className="timeline-title">Step {step}: {title}</div>
              <div className="timeline-time">{timestamps?.[String(step)] || "--:--:--"}</div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default Timeline;
