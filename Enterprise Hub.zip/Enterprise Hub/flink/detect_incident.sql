CREATE TABLE github_events (
  commit_id STRING,
  author STRING,
  service_name STRING,
  changed_files STRING,
  commit_message STRING,
  commit_time TIMESTAMP(3),
  WATERMARK FOR commit_time
    AS commit_time - INTERVAL '5' SECOND
) WITH (
  'connector' = 'confluent',
  'kafka.topic' = 'github-events',
  'value.format' = 'json'
);

CREATE TABLE app_logs (
  log_id STRING,
  service_name STRING,
  log_level STRING,
  message STRING,
  error_count INT,
  event_time TIMESTAMP(3),
  WATERMARK FOR event_time
    AS event_time - INTERVAL '5' SECOND
) WITH (
  'connector' = 'confluent',
  'kafka.topic' = 'app-logs',
  'value.format' = 'json'
);

CREATE TABLE alerts (
  alert_id STRING,
  severity STRING,
  service_name STRING,
  description STRING,
  error_count BIGINT,
  correlated_commit STRING,
  triggered_at TIMESTAMP(3)
) WITH (
  'connector' = 'confluent',
  'kafka.topic' = 'alerts',
  'value.format' = 'json'
);

INSERT INTO alerts
SELECT
  CONCAT('INC-', CAST(UNIX_TIMESTAMP() AS STRING)) AS alert_id,
  'CRITICAL' AS severity,
  l.service_name,
  CONCAT('High error rate: ',
    CAST(COUNT(*) AS STRING), ' errors in 60s') AS description,
  COUNT(*) AS error_count,
  MAX(g.commit_id) AS correlated_commit,
  TUMBLE_START(l.event_time,
    INTERVAL '60' SECOND) AS triggered_at
FROM app_logs l
LEFT JOIN github_events g
  ON l.service_name = g.service_name
  AND g.commit_time BETWEEN
    l.event_time - INTERVAL '2' HOUR AND l.event_time
WHERE l.log_level = 'ERROR'
GROUP BY
  l.service_name,
  TUMBLE(l.event_time, INTERVAL '60' SECOND)
HAVING COUNT(*) > 50;
