INSERT INTO alerts
SELECT
  CONCAT('PRED-', commit_id) AS alert_id,
  'WARNING' AS severity,
  service_name,
  CONCAT('Risky commit: ', commit_message) AS description,
  0 AS error_count,
  commit_id AS correlated_commit,
  commit_time AS triggered_at
FROM github_events
WHERE
  LOWER(commit_message) LIKE '%auth%'
  OR LOWER(commit_message) LIKE '%config%'
  OR LOWER(changed_files) LIKE '%yaml%';
