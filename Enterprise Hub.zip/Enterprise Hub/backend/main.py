import asyncio
import hashlib
import hmac
import json
import os
import time
from typing import Any, Dict

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

from auto_remediation import apply_fix
from kafka_consumer import start_consumer
from kafka_producer import publish_event
from sentinel_ai import predict_risky_commit
from slack_notifier import send_prediction_alert

app = FastAPI(title="SENTINEL", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

connected_websockets: list[WebSocket] = []


def now_str() -> str:
    return time.strftime("%I:%M:%S %p")


state: Dict[str, Any] = {
    "step": 0,
    "timeline": {
        "1": None,
        "2": None,
        "3": None,
        "4": None,
        "5": None,
        "6": None,
        "7": None,
    },
    "commit": None,
    "prediction": None,
    "streams": {
        "github-events": {"count": 0, "msg_per_sec": 0},
        "app-logs": {"count": 0, "msg_per_sec": 0},
        "metrics": {"count": 0, "msg_per_sec": 0},
        "alerts": {"count": 0, "msg_per_sec": 0},
    },
    "flink": {
        "job_name": "incident-detection",
        "events_in": 0,
        "events_out": 0,
        "status": "RUNNING",
    },
    "incident": None,
    "analysis": None,
    "slack_ts": None,
    "approved": False,
    "remediation_logs": [],
    "system_health": {
        "error_rate": 0.12,
        "latency_ms": 120,
        "success_rate": 99.98,
        "status": "HEALTHY",
    },
    "uptime_sec": 1,
}


async def broadcast(event_type: str, data: Any) -> None:
    msg = json.dumps({"type": event_type, "data": data})
    dead: list[WebSocket] = []
    for ws in connected_websockets:
        try:
            await ws.send_text(msg)
        except Exception:  # noqa: BLE001
            dead.append(ws)

    for ws in dead:
        if ws in connected_websockets:
            connected_websockets.remove(ws)


def mark_step(step: int) -> None:
    state["step"] = max(state.get("step", 0), step)
    key = str(step)
    if state["timeline"].get(key) is None:
        state["timeline"][key] = now_str()


@app.websocket("/ws")
async def websocket_handler(ws: WebSocket) -> None:
    await ws.accept()
    connected_websockets.append(ws)
    await ws.send_text(json.dumps({"type": "state", "data": state}))
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        if ws in connected_websockets:
            connected_websockets.remove(ws)


@app.on_event("startup")
async def startup() -> None:
    async def uptime_clock() -> None:
        while True:
            await asyncio.sleep(1)
            state["uptime_sec"] += 1

    asyncio.create_task(uptime_clock())
    asyncio.create_task(start_consumer(state, broadcast))


@app.post("/webhook/github")
async def github_webhook(
    request: Request,
    x_hub_signature_256: str | None = Header(default=None),
) -> Dict[str, str]:
    body = await request.body()
    secret = os.getenv("GITHUB_WEBHOOK_SECRET", "").encode("utf-8")

    if secret:
        expected = "sha256=" + hmac.new(secret, body, hashlib.sha256).hexdigest()
        if x_hub_signature_256 != expected:
            raise HTTPException(status_code=401, detail="invalid signature")

    data = json.loads(body)
    if "commits" not in data or not data["commits"]:
        return {"status": "ignored"}

    raw = data["commits"][0]
    commit = {
        "commit_id": raw["id"][:7],
        "author": raw["author"]["name"],
        "commit_message": raw["message"],
        "changed_files": raw.get("modified", []) + raw.get("added", []),
        "service_name": "auth-service",
        "timestamp": raw["timestamp"],
        "repo": data["repository"]["full_name"],
        "received_at": now_str(),
    }

    state["commit"] = commit
    mark_step(1)
    await broadcast("commit_received", commit)

    await publish_event("github-events", commit)
    state["streams"]["github-events"]["count"] += 1
    mark_step(2)
    await broadcast("stream_update", state["streams"])

    prediction = await asyncio.to_thread(predict_risky_commit, commit)
    state["prediction"] = prediction
    await broadcast("prediction_ready", prediction)

    if prediction.get("crash_probability", 0) > 70:
        await send_prediction_alert(prediction)

    return {"status": "ok"}


@app.post("/inject/logs")
async def inject_logs() -> Dict[str, Any]:
    now_ms = int(time.time() * 1000)
    for i in range(200):
        log = {
            "log_id": f"log-{now_ms}-{i}",
            "service_name": "auth-service",
            "log_level": "ERROR",
            "message": "Authentication failed - invalid token",
            "error_count": i + 1,
            "event_time": now_ms,
        }
        await publish_event("app-logs", log)

    state["streams"]["app-logs"]["count"] += 200
    state["flink"]["events_in"] += 200
    await broadcast("stream_update", state["streams"])
    await broadcast("flink_update", state["flink"])

    # Demo-safe fallback if Flink pipeline is not pushing critical alerts yet.
    fallback_alert = {
        "alert_id": f"INC-{int(time.time())}",
        "severity": "CRITICAL",
        "service_name": "auth-service",
        "description": "High error rate detected in auth-service",
        "error_count": 200,
        "correlated_commit": (state.get("commit") or {}).get("commit_id", "unknown"),
        "triggered_at": now_str(),
    }
    await publish_event("alerts", fallback_alert)

    return {"status": "logs injected", "count": 200}


@app.post("/slack/actions")
async def slack_actions(request: Request) -> Dict[str, str]:
    form = await request.form()
    payload = json.loads(form["payload"])
    action = payload["actions"][0]["action_id"]

    if action == "approve_fix":
        asyncio.create_task(run_remediation())
    return {"status": "ok"}


@app.post("/approve")
async def approve_fix() -> Dict[str, str]:
    asyncio.create_task(run_remediation())
    return {"status": "approved"}


async def run_remediation() -> None:
    if state.get("approved"):
        return

    state["approved"] = True
    mark_step(6)
    await broadcast("fix_approved", {})

    logs = await apply_fix(state.get("analysis") or {}, broadcast)
    state["remediation_logs"] = logs
    state["system_health"] = {
        "error_rate": 0.12,
        "latency_ms": 120,
        "success_rate": 99.98,
        "status": "HEALTHY",
    }
    mark_step(7)
    await broadcast("system_restored", state["system_health"])


@app.get("/state")
async def get_state() -> Dict[str, Any]:
    return state


@app.get("/health")
async def health() -> Dict[str, str]:
    return {"status": "ok", "service": "sentinel-backend"}
