import os
from typing import Any, Dict

from slack_sdk.web.async_client import AsyncWebClient

CHANNEL = os.getenv("SLACK_CHANNEL_ID", "")
TOKEN = os.getenv("SLACK_BOT_TOKEN", "")
client = AsyncWebClient(token=TOKEN) if TOKEN else None


def _enabled() -> bool:
    return bool(client and CHANNEL)


async def send_incident_alert(analysis: Dict[str, Any]) -> str:
    if not _enabled():
        return "local-dev-ts"

    response = await client.chat_postMessage(
        channel=CHANNEL,
        blocks=[
            {
                "type": "header",
                "text": {"type": "plain_text", "text": "SENTINEL Alert"},
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Root Cause:*\n{analysis['root_cause']}",
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*File:*\n{analysis['problematic_file']} (Line {analysis['problematic_line']})",
                    },
                    {"type": "mrkdwn", "text": f"*Issue:*\n{analysis['issue_summary']}"},
                    {
                        "type": "mrkdwn",
                        "text": f"*Impact:*\n{analysis['estimated_impact']}",
                    },
                    {"type": "mrkdwn", "text": f"*Fix:*\n{analysis['fix']}"},
                    {
                        "type": "mrkdwn",
                        "text": f"*Confidence:*\n{analysis['confidence']}%",
                    },
                ],
            },
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "APPROVE"},
                        "style": "primary",
                        "value": "approve",
                        "action_id": "approve_fix",
                    },
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "REJECT"},
                        "style": "danger",
                        "value": "reject",
                        "action_id": "reject_fix",
                    },
                ],
            },
        ],
    )
    return response["ts"]


async def send_prediction_alert(prediction: Dict[str, Any]) -> None:
    if not _enabled():
        return

    await client.chat_postMessage(
        channel=CHANNEL,
        blocks=[
            {
                "type": "header",
                "text": {"type": "plain_text", "text": "SENTINEL Prediction Warning"},
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Risk Level:*\n{prediction['risk_level']}",
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Crash Probability:*\n{prediction['crash_probability']}%",
                    },
                    {"type": "mrkdwn", "text": f"*Reason:*\n{prediction['reason']}"},
                    {
                        "type": "mrkdwn",
                        "text": f"*Recommendation:*\n{prediction['recommendation']}",
                    },
                ],
            },
        ],
    )
