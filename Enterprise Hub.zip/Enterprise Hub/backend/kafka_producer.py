import asyncio
import json
import os
from typing import Any, Dict

from confluent_kafka import Producer

producer_config = {
    "bootstrap.servers": os.getenv("CONFLUENT_BOOTSTRAP_SERVERS", ""),
    "security.protocol": "SASL_SSL",
    "sasl.mechanisms": "PLAIN",
    "sasl.username": os.getenv("CONFLUENT_API_KEY", ""),
    "sasl.password": os.getenv("CONFLUENT_API_SECRET", ""),
    "client.id": "sentinel-producer",
}

producer = Producer(producer_config)


def delivery_report(err, msg):
    if err:
        print(f"Delivery failed: {err}")
    else:
        print(f"Delivered to {msg.topic()} [{msg.partition()}]")


async def publish_event(topic: str, data: Dict[str, Any]) -> None:
    payload = json.dumps(data).encode("utf-8")

    def _produce() -> None:
        producer.produce(
            topic=topic,
            key=str(data.get("commit_id", data.get("alert_id", "key"))),
            value=payload,
            callback=delivery_report,
        )
        producer.poll(0)
        producer.flush(2)

    await asyncio.to_thread(_produce)
