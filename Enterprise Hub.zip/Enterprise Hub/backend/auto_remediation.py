import asyncio
import base64
import os
import time
from typing import Any, Awaitable, Callable, Dict, List

import httpx

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
REPO = os.getenv("REPO_NAME", "")
GITHUB_API = "https://api.github.com"


async def apply_fix(
    analysis: Dict[str, Any],
    broadcast: Callable[[str, Dict[str, Any]], Awaitable[None]],
) -> List[Dict[str, Any]]:
    logs: List[Dict[str, Any]] = []

    async def log(msg: str) -> None:
        entry = {
            "time": time.strftime("%I:%M:%S %p"),
            "level": "INFO",
            "message": msg,
        }
        logs.append(entry)
        await broadcast("remediation_log", entry)
        await asyncio.sleep(0.6)

    if not GITHUB_TOKEN or not REPO:
        await log("GitHub credentials are missing; remediation skipped")
        return logs

    file_path = analysis.get("problematic_file", "auth-service.yaml")

    await log("Approval received from engineer")
    await log("Starting auto remediation")

    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    async with httpx.AsyncClient(timeout=20.0) as client:
        await log(f"Reading recent commits for {file_path}")
        commits_resp = await client.get(
            f"{GITHUB_API}/repos/{REPO}/commits",
            params={"path": file_path, "per_page": 2},
            headers=headers,
        )
        commits_resp.raise_for_status()
        commits = commits_resp.json()

        if len(commits) < 2:
            await log("No previous commit available for this file")
            return logs

        previous_sha = commits[1]["sha"]

        await log("Fetching stable version from previous commit")
        content_resp = await client.get(
            f"{GITHUB_API}/repos/{REPO}/contents/{file_path}",
            params={"ref": previous_sha},
            headers=headers,
        )
        content_resp.raise_for_status()
        previous_content = content_resp.json()
        restored_content = base64.b64decode(previous_content["content"]).decode("utf-8")

        await log("Fetching current file SHA")
        current_resp = await client.get(
            f"{GITHUB_API}/repos/{REPO}/contents/{file_path}",
            headers=headers,
        )
        current_resp.raise_for_status()
        current_sha = current_resp.json()["sha"]

        await log(f"Reverting {file_path}")
        put_resp = await client.put(
            f"{GITHUB_API}/repos/{REPO}/contents/{file_path}",
            headers=headers,
            json={
                "message": "SENTINEL auto-fix: restore previous stable config",
                "content": base64.b64encode(restored_content.encode("utf-8")).decode("utf-8"),
                "sha": current_sha,
            },
        )
        put_resp.raise_for_status()

    await log("Deployment rollback triggered")
    await log("Service auth-service restarting")
    await log("Health check passed")
    await log("Incident resolved")
    await log("Notification sent to Slack")

    return logs
