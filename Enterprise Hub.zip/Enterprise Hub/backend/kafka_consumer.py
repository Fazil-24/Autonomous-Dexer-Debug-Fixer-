import asyncio
import json
import os
from typing import Any, Awaitable, Callable, Dict

from confluent_kafka import Consumer

from sentinel_ai import analyze_incident
from slack_notifier import send_incident_alert

consumer_config = {
    "bootstrap.servers": os.getenv("CONFLUENT_BOOTSTRAP_SERVERS", ""),
    "security.protocol": "SASL_SSL",
    "sasl.mechanisms": "PLAIN",
    "sasl.username": os.getenv("CONFLUENT_API_KEY", ""),
    "sasl.password": os.getenv("CONFLUENT_API_SECRET", ""),
    "group.id": "sentinel-consumer-group",
    "auto.offset.reset": "latest",
    "enable.auto.commit": True,
}


async def start_consumer(
    state: Dict[str, Any],
    broadcast: Callable[[str, Any], Awaitable[None]],
) -> None:
    consumer = Consumer(consumer_config)
    consumer.subscribe(["github-events", "app-logs", "metrics", "alerts"])

    loop = asyncio.get_running_loop()

    try:
        while True:
            msg = await loop.run_in_executor(None, lambda: consumer.poll(1.0))

            if msg is None:
                continue

            if msg.error():
                print(f"Consumer error: {msg.error()}")
                continue

            topic = msg.topic()
            data = json.loads(msg.value().decode("utf-8"))

            if topic in state["streams"]:
                state["streams"][topic]["count"] += 1
                state["streams"][topic]["msg_per_sec"] = round(
                    state["streams"][topic]["count"] / max(1, state.get("uptime_sec", 1)),
                    2,
                )
                await broadcast("stream_update", state["streams"])

            if topic == "alerts":
                severity = str(data.get("severity", "")).upper()
                if severity == "CRITICAL" and state.get("analysis") is None:
                    state["incident"] = data
                    state["step"] = max(state.get("step", 0), 3)
                    state["flink"]["events_out"] += 1
                    await broadcast("incident_detected", data)
                    await broadcast("flink_update", state["flink"])

                    analysis = await asyncio.to_thread(
                        analyze_incident,
                        state.get("commit", {}),
                        {
                            "error_count": data.get("error_count", 0),
                            "service": data.get("service_name", ""),
                        },
                        {
                            "error_rate": 45.2,
                            "latency_ms": 8500,
                        },
                        data,
                    )

                    state["analysis"] = analysis
                    state["step"] = 4
                    await broadcast("analysis_ready", analysis)

                    ts = await send_incident_alert(analysis)
                    state["slack_ts"] = ts
                    state["step"] = 5
                    await broadcast("slack_sent", {"ts": ts})
    finally:
        consumer.close()
